var searchData=
[
  ['integer_20functions_4528',['Integer functions',['../a00981.html',1,'']]]
];
