var searchData=
[
  ['tan_3019',['tan',['../a00984.html#ga293a34cfb9f0115cc606b4a97c84f11f',1,'glm']]],
  ['tanh_3020',['tanh',['../a00984.html#gaa1bccbfdcbe40ed2ffcddc2aa8bfd0f1',1,'glm']]],
  ['tau_3021',['tau',['../a00899.html#gae645d3bb4076df6976b3c0821831b422',1,'glm']]],
  ['third_3022',['third',['../a00899.html#ga3077c6311010a214b69ddc8214ec13b5',1,'glm']]],
  ['three_5fover_5ftwo_5fpi_3023',['three_over_two_pi',['../a00899.html#gae94950df74b0ce382b1fc1d978ef7394',1,'glm']]],
  ['to_5fstring_3024',['to_string',['../a00971.html#ga8f0dced1fd45e67e2d77e80ab93c7af5',1,'glm']]],
  ['tomat3_3025',['toMat3',['../a00962.html#gac228e3fcfa813841804362fcae02b337',1,'glm']]],
  ['tomat4_3026',['toMat4',['../a00962.html#gad0d0c14d7d3c852b41d6a6e4d1da6606',1,'glm']]],
  ['toquat_3027',['toQuat',['../a00962.html#ga7b2be33d948db631c8815e9f2953a451',1,'glm::toQuat(mat&lt; 3, 3, T, Q &gt; const &amp;x)'],['../a00962.html#ga4cf12d456770d716b590fd498bce6136',1,'glm::toQuat(mat&lt; 4, 4, T, Q &gt; const &amp;x)']]],
  ['translate_3028',['translate',['../a00828.html#gac6b494bda2f47615b2fd3e70f3d2c912',1,'glm::translate(mat&lt; 4, 4, T, Q &gt; const &amp;m, vec&lt; 3, T, Q &gt; const &amp;v)'],['../a00950.html#gaf4573ae47c80938aa9053ef6a33755ab',1,'glm::translate(mat&lt; 3, 3, T, Q &gt; const &amp;m, vec&lt; 2, T, Q &gt; const &amp;v)'],['../a00973.html#ga309a30e652e58c396e2c3d4db3ee7658',1,'glm::translate(vec&lt; 3, T, Q &gt; const &amp;v)']]],
  ['transpose_3029',['transpose',['../a00825.html#ga4bedcb9c511484f38fd30a60c95f4679',1,'glm']]],
  ['trianglenormal_3030',['triangleNormal',['../a00953.html#gaff1cb5496925dfa7962df457772a7f35',1,'glm']]],
  ['trunc_3031',['trunc',['../a00803.html#gaf9375e3e06173271d49e6ffa3a334259',1,'glm']]],
  ['tweakedinfiniteperspective_3032',['tweakedInfinitePerspective',['../a00805.html#gaaeacc04a2a6f4b18c5899d37e7bb3ef9',1,'glm::tweakedInfinitePerspective(T fovy, T aspect, T near)'],['../a00805.html#gaf5b3c85ff6737030a1d2214474ffa7a8',1,'glm::tweakedInfinitePerspective(T fovy, T aspect, T near, T ep)']]],
  ['two_5fover_5fpi_3033',['two_over_pi',['../a00899.html#ga74eadc8a211253079683219a3ea0462a',1,'glm']]],
  ['two_5fover_5froot_5fpi_3034',['two_over_root_pi',['../a00899.html#ga5827301817640843cf02026a8d493894',1,'glm']]],
  ['two_5fpi_3035',['two_pi',['../a00899.html#gaa5276a4617566abcfe49286f40e3a256',1,'glm']]],
  ['two_5fthirds_3036',['two_thirds',['../a00899.html#ga9b4d2f4322edcf63a6737b92a29dd1f5',1,'glm']]]
];
