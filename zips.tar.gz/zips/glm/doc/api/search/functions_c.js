var searchData=
[
  ['one_2839',['one',['../a00899.html#ga39c2fb227631ca25894326529bdd1ee5',1,'glm']]],
  ['one_5fover_5fpi_2840',['one_over_pi',['../a00899.html#ga555150da2b06d23c8738981d5013e0eb',1,'glm']]],
  ['one_5fover_5froot_5ftwo_2841',['one_over_root_two',['../a00899.html#ga788fa23a0939bac4d1d0205fb4f35818',1,'glm']]],
  ['one_5fover_5ftwo_5fpi_2842',['one_over_two_pi',['../a00899.html#ga7c922b427986cbb2e4c6ac69874eefbc',1,'glm']]],
  ['openbounded_2843',['openBounded',['../a00923.html#gafd303042ba2ba695bf53b2315f53f93f',1,'glm']]],
  ['orientate2_2844',['orientate2',['../a00928.html#gae16738a9f1887cf4e4db6a124637608d',1,'glm']]],
  ['orientate3_2845',['orientate3',['../a00928.html#ga7ca98668a5786f19c7b38299ebbc9b4c',1,'glm::orientate3(T const &amp;angle)'],['../a00928.html#ga7238c8e15c7720e3ca6a45ab151eeabb',1,'glm::orientate3(vec&lt; 3, T, Q &gt; const &amp;angles)']]],
  ['orientate4_2846',['orientate4',['../a00928.html#ga4a044653f71a4ecec68e0b623382b48a',1,'glm']]],
  ['orientation_2847',['orientation',['../a00966.html#ga1a32fceb71962e6160e8af295c91930a',1,'glm']]],
  ['orientedangle_2848',['orientedAngle',['../a00978.html#ga9556a803dce87fe0f42fdabe4ebba1d5',1,'glm::orientedAngle(vec&lt; 2, T, Q &gt; const &amp;x, vec&lt; 2, T, Q &gt; const &amp;y)'],['../a00978.html#ga706fce3d111f485839756a64f5a48553',1,'glm::orientedAngle(vec&lt; 3, T, Q &gt; const &amp;x, vec&lt; 3, T, Q &gt; const &amp;y, vec&lt; 3, T, Q &gt; const &amp;ref)']]],
  ['ortho_2849',['ortho',['../a00805.html#gae5b6b40ed882cd56cd7cb97701909c06',1,'glm::ortho(T left, T right, T bottom, T top)'],['../a00805.html#ga6615d8a9d39432e279c4575313ecb456',1,'glm::ortho(T left, T right, T bottom, T top, T zNear, T zFar)']]],
  ['ortholh_2850',['orthoLH',['../a00805.html#gad122a79aadaa5529cec4ac197203db7f',1,'glm']]],
  ['ortholh_5fno_2851',['orthoLH_NO',['../a00805.html#ga526416735ea7c5c5cd255bf99d051bd8',1,'glm']]],
  ['ortholh_5fzo_2852',['orthoLH_ZO',['../a00805.html#gab37ac3eec8d61f22fceda7775e836afa',1,'glm']]],
  ['orthono_2853',['orthoNO',['../a00805.html#gab219d28a8f178d4517448fcd6395a073',1,'glm']]],
  ['orthonormalize_2854',['orthonormalize',['../a00957.html#ga4cab5d698e6e2eccea30c8e81c74371f',1,'glm::orthonormalize(mat&lt; 3, 3, T, Q &gt; const &amp;m)'],['../a00957.html#gac3bc7ef498815026bc3d361ae0b7138e',1,'glm::orthonormalize(vec&lt; 3, T, Q &gt; const &amp;x, vec&lt; 3, T, Q &gt; const &amp;y)']]],
  ['orthorh_2855',['orthoRH',['../a00805.html#ga16264c9b838edeb9dd1de7a1010a13a4',1,'glm']]],
  ['orthorh_5fno_2856',['orthoRH_NO',['../a00805.html#gaa2f7a1373170bf0a4a2ddef9b0706780',1,'glm']]],
  ['orthorh_5fzo_2857',['orthoRH_ZO',['../a00805.html#ga9aea2e515b08fd7dce47b7b6ec34d588',1,'glm']]],
  ['orthozo_2858',['orthoZO',['../a00805.html#gaea11a70817af2c0801c869dea0b7a5bc',1,'glm']]],
  ['outerproduct_2859',['outerProduct',['../a00825.html#ga80d31e9320fd77035336e01d0228321f',1,'glm']]]
];
