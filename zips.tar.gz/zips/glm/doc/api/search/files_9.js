var searchData=
[
  ['log_5fbase_2ehpp_2312',['log_base.hpp',['../a00650.html',1,'']]]
];
