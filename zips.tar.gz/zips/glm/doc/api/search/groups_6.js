var searchData=
[
  ['matrix_20functions_4529',['Matrix functions',['../a00982.html',1,'']]],
  ['matrix_20types_4530',['Matrix types',['../a00892.html',1,'']]],
  ['matrix_20types_20with_20precision_20qualifiers_4531',['Matrix types with precision qualifiers',['../a00893.html',1,'']]]
];
